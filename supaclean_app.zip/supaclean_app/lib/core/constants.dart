import 'package:flutter/material.dart';

class AppColors {
  static const Color primary = Color(0xFFEC1B5B);
  static const Color textDark = Color(0xFF1A1A1A);
  static const Color textGrey = Color(0xFF8A8A8A);
  static const Color border = Color(0xFFE5E5E5);
  static const Color background = Colors.white;
}

class AppStrings {
  static const String appName = 'SupaClean';
  static const String welcomeBack = 'Welcome Back';
  static const String signInSubtitle = 'Sign in to your SupaClean account';
  static const String createAccount = 'Create Your Account';
  static const String joinToday = 'Join SupaClean today';
}
